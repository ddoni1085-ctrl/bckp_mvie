<?php
include "config.php";

$session = checkToken($conn);

jsonResponse(true, "Session aktif", [
    "user_id" => $session['user_id'],
    "username" => $session['username'],
    "name" => $session['name'],
    "expired_at" => $session['user_expired']
]);