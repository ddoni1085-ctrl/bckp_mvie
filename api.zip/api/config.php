<?php
header("Content-Type: application/json; charset=utf-8");

include "../koneksi.php";

function jsonResponse($success, $message, $data = []) {
    echo json_encode([
        "success" => $success,
        "message" => $message,
        "data" => $data
    ]);
    exit;
}

function getBearerToken() {
    $auth = null;

    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $auth = $_SERVER['HTTP_AUTHORIZATION'];
    } elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $auth = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    } elseif (function_exists('getallheaders')) {
        $headers = getallheaders();

        if (isset($headers['Authorization'])) {
            $auth = $headers['Authorization'];
        } elseif (isset($headers['authorization'])) {
            $auth = $headers['authorization'];
        }
    }

    if (!$auth) {
        return null;
    }

    if (preg_match('/Bearer\s+(.+)/', $auth, $matches)) {
        return trim($matches[1]);
    }

    return null;
}

function checkToken($conn) {
    $token = getBearerToken();

    if (!$token) {
        jsonResponse(false, "Token tidak ditemukan");
    }

    $token = mysqli_real_escape_string($conn, $token);

    $q = mysqli_query($conn, "
        SELECT s.*, u.username, u.name, u.expired_at AS user_expired, u.status AS user_status
        FROM sessions s
        JOIN users u ON s.user_id = u.id
        WHERE s.token='$token'
        LIMIT 1
    ");

    $session = mysqli_fetch_assoc($q);

    if (!$session) {
        jsonResponse(false, "Session tidak valid");
    }

    if (strtotime($session['expired_at']) < time()) {
        mysqli_query($conn, "DELETE FROM sessions WHERE token='$token'");
        jsonResponse(false, "Session expired");
    }

    if ($session['user_status'] !== 'active') {
        jsonResponse(false, "Akun tidak aktif");
    }

    if (strtotime($session['user_expired']) < time()) {
        mysqli_query($conn, "DELETE FROM sessions WHERE user_id='".$session['user_id']."'");
        jsonResponse(false, "Masa aktif akun sudah habis");
    }

    return $session;
}