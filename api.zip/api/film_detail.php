<?php
include "config.php";

checkToken($conn);

$film_id = (int)($_GET['film_id'] ?? 0);

if ($film_id <= 0) {
    jsonResponse(false, "Film tidak valid");
}

$qFilm = mysqli_query($conn, "
    SELECT f.*, c.name AS category_name
    FROM films f
    LEFT JOIN categories c ON f.category_id = c.id
    WHERE f.id='$film_id' AND f.status='active'
    LIMIT 1
");

$film = mysqli_fetch_assoc($qFilm);

if (!$film) {
    jsonResponse(false, "Film tidak ditemukan");
}

$qEpisodes = mysqli_query($conn, "
    SELECT id, episode_number, title, video_type, status
    FROM episodes
    WHERE film_id='$film_id' AND status='active'
    ORDER BY episode_number ASC
");

$episodes = [];

while ($ep = mysqli_fetch_assoc($qEpisodes)) {
    $episodes[] = [
        "id" => $ep['id'],
        "episode_number" => $ep['episode_number'],
        "title" => $ep['title'],
        "video_type" => $ep['video_type']
    ];
}

jsonResponse(true, "Detail film berhasil diambil", [
    "film" => [
        "id" => $film['id'],
        "title" => $film['title'],
        "type" => $film['type'],
        "poster_url" => $film['poster_url'],
        "backdrop_url" => $film['backdrop_url'],
        "description" => $film['description'],
        "genre" => $film['genre'],
        "year" => $film['year'],
        "rating" => $film['rating'],
        "category" => $film['category_name']
    ],
    "episodes" => $episodes
]);