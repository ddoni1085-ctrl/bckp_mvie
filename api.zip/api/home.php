<?php
include "config.php";

checkToken($conn);

$q = mysqli_query($conn, "
    SELECT 
        f.id,
        f.category_id,
        f.title,
        f.slug,
        f.type,
        f.poster_url,
        f.backdrop_url,
        f.description,
        f.genre,
        f.year,
        f.rating,
        f.status,
        f.created_at,
        f.updated_at,
        c.name AS category_name,
        COUNT(w.id) AS play_count
    FROM films f
    LEFT JOIN categories c ON f.category_id = c.id
    LEFT JOIN watch_logs w ON w.film_id = f.id
    WHERE f.status='active'
    GROUP BY 
        f.id,
        f.category_id,
        f.title,
        f.slug,
        f.type,
        f.poster_url,
        f.backdrop_url,
        f.description,
        f.genre,
        f.year,
        f.rating,
        f.status,
        f.created_at,
        f.updated_at,
        c.name
    ORDER BY f.id DESC
");

if (!$q) {
    jsonResponse(false, "Query gagal: " . mysqli_error($conn));
}

$films = [];

while ($row = mysqli_fetch_assoc($q)) {
    $films[] = [
        "id" => (int)$row['id'],
        "title" => $row['title'],
        "type" => $row['type'],
        "poster_url" => $row['poster_url'],
        "backdrop_url" => $row['backdrop_url'],
        "description" => $row['description'],
        "genre" => $row['genre'],
        "year" => $row['year'],
        "rating" => $row['rating'],
        "category" => $row['category_name'],
        "play_count" => (int)$row['play_count']
    ];
}

jsonResponse(true, "Data film berhasil diambil", $films);