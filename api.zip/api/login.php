<?php
include "config.php";

$username = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
$password = $_POST['password'] ?? '';
$device_id = mysqli_real_escape_string($conn, $_POST['device_id'] ?? '');
$device_name = mysqli_real_escape_string($conn, $_POST['device_name'] ?? 'Android TV');

if (!$username || !$password || !$device_id) {
    jsonResponse(false, "Data login tidak lengkap");
}

$q = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' LIMIT 1");
$user = mysqli_fetch_assoc($q);

if (!$user || !password_verify($password, $user['password'])) {
    jsonResponse(false, "Username atau password salah");
}

if ($user['status'] !== 'active') {
    jsonResponse(false, "Akun tidak aktif");
}

if (strtotime($user['expired_at']) < time()) {
    mysqli_query($conn, "UPDATE users SET status='expired' WHERE id='".$user['id']."'");
    jsonResponse(false, "Masa aktif akun sudah habis");
}

$user_id = (int)$user['id'];

$deviceCheck = mysqli_query($conn, "
    SELECT * FROM devices 
    WHERE user_id='$user_id' AND device_id='$device_id'
    LIMIT 1
");

if (mysqli_num_rows($deviceCheck) == 0) {
    $totalDevice = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT COUNT(*) AS total FROM devices WHERE user_id='$user_id'
    "))['total'];

    if ($totalDevice >= $user['max_devices']) {
        jsonResponse(false, "Akun sudah digunakan di perangkat lain");
    }

    mysqli_query($conn, "
        INSERT INTO devices (user_id, device_id, device_name, last_login)
        VALUES ('$user_id', '$device_id', '$device_name', NOW())
    ");
} else {
    mysqli_query($conn, "
        UPDATE devices SET last_login=NOW(), device_name='$device_name'
        WHERE user_id='$user_id' AND device_id='$device_id'
    ");
}

$token = bin2hex(random_bytes(32));
$session_expired = date("Y-m-d H:i:s", strtotime("+30 days"));

mysqli_query($conn, "DELETE FROM sessions WHERE user_id='$user_id' AND device_id='$device_id'");

mysqli_query($conn, "
    INSERT INTO sessions (user_id, token, device_id, expired_at)
    VALUES ('$user_id', '$token', '$device_id', '$session_expired')
");

jsonResponse(true, "Login berhasil", [
    "token" => $token,
    "user" => [
        "id" => $user['id'],
        "username" => $user['username'],
        "name" => $user['name'],
        "expired_at" => $user['expired_at'],
        "max_devices" => $user['max_devices']
    ]
]);