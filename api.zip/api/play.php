<?php
include "config.php";

$session = checkToken($conn);

$episode_id = (int)($_GET['episode_id'] ?? 0);

if ($episode_id <= 0) {
    jsonResponse(false, "Episode tidak valid");
}

$q = mysqli_query($conn, "
    SELECT e.*, f.id AS film_id, f.title AS film_title
    FROM episodes e
    JOIN films f ON e.film_id = f.id
    WHERE e.id='$episode_id'
      AND e.status='active'
      AND f.status='active'
    LIMIT 1
");

$ep = mysqli_fetch_assoc($q);

if (!$ep) {
    jsonResponse(false, "Video tidak ditemukan");
}

mysqli_query($conn, "
    INSERT INTO watch_logs 
    (user_id, film_id, episode_id, progress_seconds, duration_seconds, watched_at)
    VALUES 
    ('".$session['user_id']."', '".$ep['film_id']."', '".$ep['id']."', 0, 0, NOW())
");

jsonResponse(true, "Video siap diputar", [
    "episode_id" => $ep['id'],
    "film_id" => $ep['film_id'],
    "film_title" => $ep['film_title'],
    "episode_title" => $ep['title'],
    "video_type" => $ep['video_type'],
    "video_url" => $ep['video_url'],
    "headers" => [
        "Referer" => $ep['referer'],
        "Origin" => $ep['origin'],
        "User-Agent" => $ep['user_agent']
    ]
]);