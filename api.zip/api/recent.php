<?php
include "config.php";

$session = checkToken($conn);
$user_id = (int)$session['user_id'];

$q = mysqli_query($conn, "
    SELECT 
        f.id,
        f.title,
        f.type,
        f.poster_url,
        f.backdrop_url,
        f.description,
        f.genre,
        f.year,
        f.rating,
        c.name AS category_name,
        e.id AS episode_id,
        e.episode_number,
        e.title AS episode_title,
        MAX(w.watched_at) AS last_watched
    FROM watch_logs w
    JOIN films f ON w.film_id = f.id
    LEFT JOIN episodes e ON w.episode_id = e.id
    LEFT JOIN categories c ON f.category_id = c.id
    WHERE w.user_id='$user_id'
      AND f.status='active'
    GROUP BY 
        f.id, f.title, f.type, f.poster_url, f.backdrop_url,
        f.description, f.genre, f.year, f.rating, c.name,
        e.id, e.episode_number, e.title
    ORDER BY last_watched DESC
    LIMIT 20
");

if (!$q) {
    jsonResponse(false, "Query gagal: " . mysqli_error($conn));
}

$data = [];

while ($row = mysqli_fetch_assoc($q)) {
    $data[] = [
        "film" => [
            "id" => (int)$row['id'],
            "title" => $row['title'],
            "type" => $row['type'],
            "poster_url" => $row['poster_url'],
            "backdrop_url" => $row['backdrop_url'],
            "description" => $row['description'],
            "genre" => $row['genre'],
            "year" => $row['year'],
            "rating" => $row['rating'],
            "category" => $row['category_name']
        ],
        "episode" => [
            "id" => (int)$row['episode_id'],
            "episode_number" => (int)$row['episode_number'],
            "title" => $row['episode_title']
        ],
        "last_watched" => $row['last_watched']
    ];
}

jsonResponse(true, "Recent play berhasil diambil", $data);